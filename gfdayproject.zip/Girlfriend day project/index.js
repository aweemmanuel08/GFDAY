const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.render('index');
});

app.get('/love', (req, res) => {
  const { to, msg } = req.query;
  res.render('love', {
    to: to || "My Love",
    msg: msg || "You're my everything."
  });

  // Save to savedLinks.json
  const entry = {
    to,
    msg,
    url: `/love?to=${encodeURIComponent(to)}&msg=${encodeURIComponent(msg)}`,
    timestamp: new Date().toISOString()
  };

  fs.readFile('savedLinks.json', 'utf8', (err, data) => {
    let links = [];
    if (!err && data) {
      try {
        links = JSON.parse(data);
      } catch (e) { links = []; }
    }
    links.push(entry);
    fs.writeFile('savedLinks.json', JSON.stringify(links, null, 2), () => {});
  });
});

// Optional route to view all saved links
app.get('/all-links', (req, res) => {
  fs.readFile('savedLinks.json', 'utf8', (err, data) => {
    if (err || !data) return res.send('No links yet.');
    const links = JSON.parse(data);
    res.send(
      `<h1>Saved Love Links 💌</h1>` +
      links.map(link =>
        `<p><strong>To:</strong> ${link.to}<br><a href="${link.url}">${link.url}</a></p>`
      ).join('<hr>')
    );
  });
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));