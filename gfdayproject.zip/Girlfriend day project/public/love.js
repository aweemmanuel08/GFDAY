// Floating "I love you ❤️" on click + counter
let clickCounter = 0;

document.body.addEventListener('click', function (e) {
  const heart = document.createElement('div');
  heart.textContent = 'I love you ❤️';
  heart.style.position = 'absolute';
  heart.style.left = e.pageX + 'px';
  heart.style.top = e.pageY + 'px';
  heart.style.color = '#ff1493';
  heart.style.fontSize = '1.2em';
  heart.style.animation = 'fadeUp 2s forwards';
  document.body.appendChild(heart);
  setTimeout(() => heart.remove(), 2000);

  clickCounter++;
  document.querySelector('#clickCount span').textContent = clickCounter;
});

// Floating heart/rose animation
const style = document.createElement('style');
style.innerHTML = `
  @keyframes fadeUp {
    0% {opacity: 1; transform: translateY(0);}
    100% {opacity: 0; transform: translateY(-100px);}
  }

  .floating-heart {
    position: fixed;
    bottom: -30px;
    font-size: 24px;
    animation: floatHeart 10s linear infinite;
    pointer-events: none;
    color: #ff69b4;
  }

  @keyframes floatHeart {
    0% {transform: translateY(0) scale(1); opacity: 0;}
    50% {opacity: 1;}
    100% {transform: translateY(-100vh) scale(1.5); opacity: 0;}
  }
`;
document.head.appendChild(style);

function createFloatingHeart() {
  const heart = document.createElement('div');
  heart.className = 'floating-heart';
  heart.textContent = '💖';
  heart.style.left = `${Math.random() * 100}vw`;
  heart.style.animationDuration = `${6 + Math.random() * 4}s`;
  document.body.appendChild(heart);
  setTimeout(() => heart.remove(), 10000);
}
setInterval(createFloatingHeart, 1000);

// Music toggle
document.getElementById('toggleMusic').addEventListener('click', () => {
  const music = document.getElementById('bg-music');
  const toggleBtn = document.getElementById('toggleMusic');
  if (music.paused) {
    music.play();
    toggleBtn.textContent = '🔊 Music On';
  } else {
    music.pause();
    toggleBtn.textContent = '🔇 Music Off';
  }
});